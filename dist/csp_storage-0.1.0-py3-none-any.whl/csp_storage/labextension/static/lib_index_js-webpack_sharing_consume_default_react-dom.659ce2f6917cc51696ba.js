"use strict";
(self["webpackChunkcsp_storage"] = self["webpackChunkcsp_storage"] || []).push([["lib_index_js-webpack_sharing_consume_default_react-dom"],{

/***/ "./lib/components/intro.js":
/*!*********************************!*\
  !*** ./lib/components/intro.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IntroComponent": () => (/* binding */ IntroComponent),
/* harmony export */   "IntroWidget": () => (/* binding */ IntroWidget),
/* harmony export */   "PageType": () => (/* binding */ PageType)
/* harmony export */ });
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/Button.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/InputLabel/InputLabel */ "./node_modules/@material-ui/core/InputLabel/InputLabel.js");
/* harmony import */ var _material_ui_core_FormHelperText_FormHelperText__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/FormHelperText/FormHelperText */ "./node_modules/@material-ui/core/FormHelperText/FormHelperText.js");
/* harmony import */ var _material_ui_core_NativeSelect_NativeSelect__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/NativeSelect/NativeSelect */ "./node_modules/@material-ui/core/NativeSelect/NativeSelect.js");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/Typography.js");
/* harmony import */ var _material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/Grid/Grid */ "./node_modules/@material-ui/core/Grid/Grid.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/TextField */ "./node_modules/@material-ui/core/esm/TextField/TextField.js");


//import ReactDOM from 'react-dom';


//import Container from '@material-ui/core/Container';







var PageType;
(function (PageType) {
    PageType[PageType["SelectCSP"] = 0] = "SelectCSP";
    PageType[PageType["CSPDetails"] = 1] = "CSPDetails";
    PageType[PageType["ViewList"] = 2] = "ViewList";
})(PageType || (PageType = {}));
class IntroComponent extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
    constructor(props) {
        super(props);
        this.OnSelectCSP = async () => {
            // GET request
            try {
                const data = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('get_example');
                this.setState({
                    myval: JSON.stringify(data),
                    page: PageType.CSPDetails
                });
                console.log(data);
            }
            catch (reason) {
                console.error(`The mix server extension appears to be missing.\n${reason}`);
            }
        };
        this.OnCSPDetails = async (event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            console.log(data.get('ACCESS_KEY_ID'));
            const dataToSend = {
                ACCESS_KEY_ID: data.get('ACCESS_KEY_ID'),
                SECRET_ACCESS_KEY: data.get('SECRET_ACCESS_KEY'),
                BUCKET_NAME: data.get('BUCKET_NAME'),
            };
            // GET request
            try {
                const reply = await (0,_handler__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('get_example', {
                    body: JSON.stringify(dataToSend),
                    method: 'POST',
                });
                this.setState({
                    myval: JSON.stringify(data),
                    page: PageType.ViewList
                });
                console.log(reply);
            }
            catch (reason) {
                console.error(`The mix server extension appears to be missing.\n${reason}`);
            }
        };
        this.state = {
            myval: 'hello',
            showlist: false,
            page: PageType.SelectCSP
        };
    }
    render() {
        const pageState = this.state.page;
        let _renderTest;
        switch (pageState) {
            case PageType.SelectCSP:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__["default"], { shrink: true, htmlFor: "age-native-label-placeholder" }, "Cloud Storage Provider"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_NativeSelect_NativeSelect__WEBPACK_IMPORTED_MODULE_6__["default"], null,
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 10 }, "Amazon S3"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 20, disabled: true }, "Azure Blob Storage"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 30, disabled: true }, "Google Cloud Storage"))),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_FormHelperText_FormHelperText__WEBPACK_IMPORTED_MODULE_7__["default"], null, "Storage Provider to import from.")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_8__["default"], { variant: "contained", color: "primary", onClick: () => this.OnSelectCSP() }, "Configure")));
                break;
            case PageType.CSPDetails:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { noValidate: true, autoComplete: "off", onSubmit: this.OnCSPDetails },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__["default"], { shrink: true, htmlFor: "age-native-label-placeholder" }, "Access Key"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { required: true, name: "ACCESS_KEY_ID", id: "ACCESS_KEY_ID", label: "", variant: "outlined" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__["default"], { shrink: true, htmlFor: "age-native-label-placeholder" }, "Secret Access Key"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { required: true, name: "SECRET_ACCESS_KEY", id: "SECRET_ACCESS_KEY", label: "", variant: "outlined" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__["default"], { shrink: true, htmlFor: "age-native-label-placeholder" }, "Bucket Name"),
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_9__["default"], { required: true, name: "BUCKET_NAME", id: "BUCKET_NAME", label: "", variant: "outlined" })),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_8__["default"], { variant: "contained", type: "submit", color: "primary" }, "Submit"))));
                break;
            case PageType.ViewList:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, this.state.myval);
                break;
            default:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, "hello");
                break;
        }
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { container: true, spacing: 10, direction: "column", alignItems: "center", justify: "center", style: { minHeight: '30vh' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_4__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_10__["default"], { variant: "h6", component: "h1", gutterBottom: true }, "Intel\u00AE DevCloud Storage Connector")),
                _renderTest)));
    }
}
class IntroWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor() {
        super();
        this.addClass('intro-page-view');
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(IntroComponent, null)));
    }
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'csp-storage', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./handler */ "./lib/handler.js");
/* harmony import */ var _components_intro__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./components/intro */ "./lib/components/intro.js");



/**
 * Initialization data for the csp-storage extension.
 */
const plugin = {
    id: 'csp-storage:plugin',
    autoStart: true,
    requires: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer
    ],
    activate: async (app, restorer) => {
        console.log('JupyterLab extension csp-storage is activated!');
        const introWidget = new _components_intro__WEBPACK_IMPORTED_MODULE_1__.IntroWidget();
        introWidget.title.iconClass = 'test1-icon';
        introWidget.title.caption = 'Cloud Storage Connector';
        introWidget.id = 'intro-page-view';
        restorer.add(introWidget, 'intropage');
        app.shell.add(introWidget, 'left', { rank: 1000 });
        (0,_handler__WEBPACK_IMPORTED_MODULE_2__.requestAPI)('get_example')
            .then(data => {
            console.log(data);
        })
            .catch(reason => {
            console.error(`The mix server extension appears to be missing.\n${reason}`);
        });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js-webpack_sharing_consume_default_react-dom.659ce2f6917cc51696ba.js.map