(self["webpackChunkcsp_storage"] = self["webpackChunkcsp_storage"] || []).push([["style_index_js"],{

/***/ "./node_modules/css-loader/dist/cjs.js!./style/base.css":
/*!**************************************************************!*\
  !*** ./node_modules/css-loader/dist/cjs.js!./style/base.css ***!
  \**************************************************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/cssWithMappingToString.js */ "./node_modules/css-loader/dist/runtime/cssWithMappingToString.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/api.js */ "./node_modules/css-loader/dist/runtime/api.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../node_modules/css-loader/dist/runtime/getUrl.js */ "./node_modules/css-loader/dist/runtime/getUrl.js");
/* harmony import */ var _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _icon_svg__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./icon.svg */ "./style/icon.svg");
/* harmony import */ var _icon_svg__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_icon_svg__WEBPACK_IMPORTED_MODULE_3__);
// Imports




var ___CSS_LOADER_EXPORT___ = _node_modules_css_loader_dist_runtime_api_js__WEBPACK_IMPORTED_MODULE_1___default()((_node_modules_css_loader_dist_runtime_cssWithMappingToString_js__WEBPACK_IMPORTED_MODULE_0___default()));
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _node_modules_css_loader_dist_runtime_getUrl_js__WEBPACK_IMPORTED_MODULE_2___default()((_icon_svg__WEBPACK_IMPORTED_MODULE_3___default()));
// Module
___CSS_LOADER_EXPORT___.push([module.id, "/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n.intro-page-view {\n    background-color: white;\n    height: 100%;\n    align-items: center;\n}\n\n.test1-icon {\n    background-image: url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ");\n}\n\n.centered {\n    display: grid;\n    justify-content: center;\n    align-items: center;\n}", "",{"version":3,"sources":["webpack://./style/base.css"],"names":[],"mappings":"AAAA;;;;CAIC;;AAED;IACI,uBAAuB;IACvB,YAAY;IACZ,mBAAmB;AACvB;;AAEA;IACI,yDAA+B;AACnC;;AAEA;IACI,aAAa;IACb,uBAAuB;IACvB,mBAAmB;AACvB","sourcesContent":["/*\n    See the JupyterLab Developer Guide for useful CSS Patterns:\n\n    https://jupyterlab.readthedocs.io/en/stable/developer/css.html\n*/\n\n.intro-page-view {\n    background-color: white;\n    height: 100%;\n    align-items: center;\n}\n\n.test1-icon {\n    background-image: url(icon.svg);\n}\n\n.centered {\n    display: grid;\n    justify-content: center;\n    align-items: center;\n}"],"sourceRoot":""}]);
// Exports
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./style/base.css":
/*!************************!*\
  !*** ./style/base.css ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! !../node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js */ "./node_modules/style-loader/dist/runtime/injectStylesIntoStyleTag.js");
/* harmony import */ var _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! !!../node_modules/css-loader/dist/cjs.js!./base.css */ "./node_modules/css-loader/dist/cjs.js!./style/base.css");

            

var options = {};

options.insert = "head";
options.singleton = false;

var update = _node_modules_style_loader_dist_runtime_injectStylesIntoStyleTag_js__WEBPACK_IMPORTED_MODULE_0___default()(_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__["default"], options);



/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (_node_modules_css_loader_dist_cjs_js_base_css__WEBPACK_IMPORTED_MODULE_1__["default"].locals || {});

/***/ }),

/***/ "./style/icon.svg":
/*!************************!*\
  !*** ./style/icon.svg ***!
  \************************/
/***/ ((module) => {

module.exports = "data:image/svg+xml,%3C!-- Generator: Adobe Illustrator 19.0.0, SVG Export Plug-In . SVG Version: 6.00 Build 0) --%3E %3Csvg version='1.1' id='Layer_1' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' x='0px' y='0px' viewBox='0 0 512 512' style='enable-background:new 0 0 512 512;' xml:space='preserve'%3E %3Cpath style='fill:%236FC5D6;' d='M417.866,125.315c-11.459,0-22.388,2.255-32.38,6.335C371.243,73.361,318.678,30.1,256,30.1 S140.757,73.361,126.514,131.65c-9.99-4.08-20.921-6.335-32.38-6.335c-47.328,0-85.694,38.366-85.694,85.694 c0,47.327,38.366,85.694,85.694,85.694h323.733c47.328,0,85.694-38.367,85.694-85.694 C503.56,163.681,465.194,125.315,417.866,125.315z'/%3E %3Cpath d='M417.866,117.719c-9.119,0-18.058,1.29-26.684,3.839c-8.461-26.728-24.923-50.724-47.023-68.304 c-25.292-20.117-55.776-30.75-88.16-30.75s-62.868,10.634-88.16,30.752c-22.1,17.579-38.563,41.577-47.023,68.304 c-8.625-2.551-17.564-3.839-26.684-3.839C42.228,117.719,0,159.948,0,211.853s42.228,94.134,94.134,94.134h128.108 c4.662,0,8.44-3.779,8.44-8.44s-3.778-8.44-8.44-8.44H94.134c-42.598,0-77.255-34.656-77.255-77.255s34.656-77.255,77.255-77.255 c10.094,0,19.914,1.921,29.187,5.709c2.274,0.928,4.838,0.821,7.026-0.295c2.186-1.115,3.78-3.129,4.363-5.514 C148.398,78.496,198.273,39.383,256,39.383s107.602,39.112,121.289,95.115c0.583,2.386,2.176,4.399,4.363,5.514 c2.188,1.116,4.752,1.223,7.026,0.295c9.273-3.788,19.095-5.709,29.187-5.709c42.598,0,77.255,34.656,77.255,77.255 s-34.656,77.255-77.255,77.255H289.758c-4.662,0-8.44,3.779-8.44,8.44s3.778,8.44,8.44,8.44h128.108 c51.906,0,94.134-42.228,94.134-94.134S469.772,117.719,417.866,117.719z'/%3E %3Cpath d='M283.187,440.274c-3.878-2.585-9.118-1.537-11.703,2.341l-7.044,10.566V211.854c0-4.661-3.778-8.44-8.44-8.44 s-8.44,3.779-8.44,8.44v241.326l-7.044-10.566c-2.585-3.879-7.825-4.925-11.703-2.341c-3.878,2.586-4.926,7.825-2.341,11.704 l22.506,33.758c0.001,0.002,0.003,0.004,0.004,0.007c0.179,0.268,0.375,0.522,0.583,0.767c0.059,0.069,0.119,0.132,0.18,0.198 c0.153,0.17,0.313,0.333,0.479,0.491c0.077,0.072,0.153,0.142,0.233,0.212c0.176,0.154,0.359,0.299,0.548,0.438 c0.064,0.047,0.126,0.098,0.192,0.144c0.262,0.182,0.535,0.351,0.817,0.503c0.008,0.005,0.016,0.007,0.023,0.011 c0.271,0.144,0.551,0.271,0.839,0.386c0.073,0.029,0.147,0.054,0.222,0.081c0.226,0.083,0.457,0.158,0.693,0.221 c0.089,0.025,0.179,0.047,0.269,0.069c0.232,0.055,0.468,0.098,0.707,0.133c0.087,0.012,0.171,0.029,0.259,0.039 c0.321,0.037,0.645,0.061,0.975,0.061c0.33,0,0.655-0.024,0.974-0.061c0.087-0.01,0.172-0.027,0.259-0.039 c0.239-0.035,0.475-0.079,0.707-0.133c0.09-0.021,0.18-0.045,0.269-0.069c0.235-0.064,0.466-0.137,0.693-0.221 c0.073-0.027,0.147-0.052,0.221-0.081c0.288-0.115,0.568-0.241,0.839-0.386c0.008-0.005,0.016-0.007,0.023-0.011 c0.282-0.152,0.555-0.322,0.817-0.503c0.066-0.046,0.128-0.097,0.192-0.144c0.189-0.138,0.371-0.284,0.548-0.438 c0.079-0.069,0.156-0.14,0.233-0.212c0.167-0.156,0.325-0.321,0.479-0.491c0.06-0.066,0.122-0.129,0.18-0.198 c0.208-0.245,0.404-0.5,0.583-0.767c0.001-0.002,0.003-0.005,0.004-0.007l22.505-33.758 C288.113,448.099,287.064,442.859,283.187,440.274z'/%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3Cg%3E %3C/g%3E %3C/svg%3E"

/***/ }),

/***/ "./style/index.js":
/*!************************!*\
  !*** ./style/index.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _base_css__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./base.css */ "./style/base.css");



/***/ })

}]);
//# sourceMappingURL=style_index_js.53b1c672f3432db19e0c.js.map