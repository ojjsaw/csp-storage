"use strict";
(self["webpackChunkcsp_storage"] = self["webpackChunkcsp_storage"] || []).push([["lib_index_js"],{

/***/ "./lib/components/cspDetails.js":
/*!**************************************!*\
  !*** ./lib/components/cspDetails.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "PageType": () => (/* binding */ PageType),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Grid/Grid */ "./node_modules/@material-ui/core/Grid/Grid.js");
/* harmony import */ var _material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/InputLabel/InputLabel */ "./node_modules/@material-ui/core/InputLabel/InputLabel.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/Button.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/TextField */ "./node_modules/@material-ui/core/esm/TextField/TextField.js");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/Typography.js");







var PageType;
(function (PageType) {
    PageType[PageType["SelectCSP"] = 0] = "SelectCSP";
    PageType[PageType["CSPDetails"] = 1] = "CSPDetails";
    PageType[PageType["ViewImportList"] = 2] = "ViewImportList";
})(PageType || (PageType = {}));
class CspDetails extends react__WEBPACK_IMPORTED_MODULE_0__.Component {
    constructor(props) {
        super(props);
        this.OnCSPDetails = async (event) => {
            event.preventDefault();
            const data = new FormData(event.currentTarget);
            const dataToSend = {
                ACCESS_KEY_ID: data.get('ACCESS_KEY_ID'),
                SECRET_ACCESS_KEY: data.get('SECRET_ACCESS_KEY'),
                BUCKET_NAME: data.get('BUCKET_NAME'),
            };
            // POST request fpr saving config details
            try {
                const configResponse = await (0,_handler__WEBPACK_IMPORTED_MODULE_1__.requestAPI)('config_api', {
                    body: JSON.stringify(dataToSend),
                    method: 'POST',
                });
                if (configResponse.isValid) {
                    this.props.stateHandler({
                        myval: JSON.stringify(configResponse),
                        page: 2,
                        userName: configResponse.username,
                        bucketName: configResponse.bucketName
                    });
                }
                else {
                    let val = {
                        myval: 'hello',
                        showlist: false,
                        page: 0,
                        listArray: [],
                        errorMsg: 'Please enter valid AWS S3 Credentials'
                    };
                    this.setState(val);
                }
            }
            catch (reason) {
                console.error(`config details cannot be saved \n${reason}`);
            }
        };
        this.state = {
            myval: 'hello',
            showlist: false,
            page: 0,
            listArray: [],
            errorMsg: ''
        };
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement("form", { noValidate: true, autoComplete: "off", onSubmit: this.OnCSPDetails },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_2__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_3__["default"], { style: { marginBottom: "1em", marginTop: "1em" }, shrink: true, htmlFor: "age-native-label-placeholder" },
                        "AWS S3 Bucket Name",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: "red" } }, "*")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__["default"], { required: true, name: "BUCKET_NAME", id: "BUCKET_NAME", label: "", variant: "outlined", style: { width: "110%" } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_2__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_3__["default"], { style: { marginTop: "1em", marginBottom: "1em" }, shrink: true, htmlFor: "age-native-label-placeholder" },
                        "AWS Access Key",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: "red" } }, "*")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__["default"], { required: true, name: "ACCESS_KEY_ID", id: "ACCESS_KEY_ID", label: "", variant: "outlined", style: { width: "110%" } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_2__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_3__["default"], { style: { marginTop: "1em", marginBottom: "1em" }, shrink: true, htmlFor: "age-native-label-placeholder" },
                        "AWS Secret Key",
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("span", { style: { color: "red" } }, "*")),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_TextField__WEBPACK_IMPORTED_MODULE_4__["default"], { required: true, name: "SECRET_ACCESS_KEY", id: "SECRET_ACCESS_KEY", label: "", variant: "outlined", type: "password", style: { width: "110%" } })),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_2__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_5__["default"], { style: { marginTop: "1em", marginBottom: "1em" }, variant: "contained", type: "submit", color: "primary" }, "Connect")),
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginTop: "1em" } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_6__["default"], { style: { fontSize: "0.85rem", fontWeight: "bold", color: "red" }, variant: "h6", align: "left" }, this.state.errorMsg)))));
    }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (CspDetails);


/***/ }),

/***/ "./lib/components/importFileData.js":
/*!******************************************!*\
  !*** ./lib/components/importFileData.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "convertPath": () => (/* binding */ convertPath)
/* harmony export */ });
var convertPath = function (pathList) {
    //console.log("Path list ::", pathList)
    let idvalue = 0;
    //const pathes = ["path1/subpath1/file1.doc", "path2/subpath2/file2.doc"],
    //getFolderListDetails();
    //console.log("path list data ::",data);
    if (pathList) {
        var result = pathList.reduce((r, path) => {
            var path = path.replace('/home/', '');
            path.split('/').reduce((children, name) => {
                //console.log("childeren", name);
                if (name != "") {
                    let child = children.find((n) => n.name === name);
                    if (!child)
                        children.push(child = { name, id: String(++idvalue), children: [] });
                    return child.children;
                }
            }, r);
            return r;
        }, []);
    }
    //console.log(result);
    return result;
};


/***/ }),

/***/ "./lib/components/intro.js":
/*!*********************************!*\
  !*** ./lib/components/intro.js ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "IntroComponent": () => (/* binding */ IntroComponent),
/* harmony export */   "IntroWidget": () => (/* binding */ IntroWidget),
/* harmony export */   "PageType": () => (/* binding */ PageType)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/Typography.js");
/* harmony import */ var _material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Grid/Grid */ "./node_modules/@material-ui/core/Grid/Grid.js");
/* harmony import */ var _storageProvider__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./storageProvider */ "./lib/components/storageProvider.js");
/* harmony import */ var _cspDetails__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cspDetails */ "./lib/components/cspDetails.js");
/* harmony import */ var _viewImportList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./viewImportList */ "./lib/components/viewImportList.js");








var PageType;
(function (PageType) {
    PageType[PageType["SelectCSP"] = 0] = "SelectCSP";
    PageType[PageType["CSPDetails"] = 1] = "CSPDetails";
    PageType[PageType["ViewImportList"] = 2] = "ViewImportList";
})(PageType || (PageType = {}));
class IntroComponent extends (react__WEBPACK_IMPORTED_MODULE_0___default().Component) {
    constructor(props) {
        super(props);
        this.stateHandler = (val) => {
            console.log("In handler", val);
            this.setState(val);
        };
        this.state = {
            myval: 'hello',
            showlist: false,
            page: PageType.SelectCSP,
            listArray: [],
            userName: '',
            bucketName: ''
        };
        this.stateHandler = this.stateHandler.bind(this);
    }
    render() {
        const pageState = this.state.page;
        let _renderTest;
        switch (pageState) {
            case PageType.SelectCSP:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_storageProvider__WEBPACK_IMPORTED_MODULE_3__["default"], { stateHandler: this.stateHandler, commands: this.props.commands });
                break;
            case PageType.CSPDetails:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_cspDetails__WEBPACK_IMPORTED_MODULE_4__["default"], { stateHandler: this.stateHandler });
                break;
            case PageType.ViewImportList:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_viewImportList__WEBPACK_IMPORTED_MODULE_5__["default"], { stateHandler: this.stateHandler, viewList: this.state.listArray, userName: this.state.userName, bucketName: this.state.bucketName, commands: this.props.commands });
                break;
            default:
                _renderTest = react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null, "hello");
                break;
        }
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { height: '90vh', overflowX: 'hidden', overflowY: 'scroll', width: '100%' } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_6__["default"], { container: true, spacing: 10, direction: "column", alignItems: "center", justify: "center", style: { margin: '-30px', marginLeft: '-70px' } },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_6__["default"], { item: true },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_7__["default"], { style: { margin: "0px" }, variant: "h6", component: "h1", gutterBottom: true }, "Cloud Storage Connector")),
                _renderTest)));
    }
}
class IntroWidget extends _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_1__.ReactWidget {
    constructor(commands) {
        super();
        this.addClass('intro-page-view');
        this._commands = commands;
        this.layout = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.PanelLayout();
    }
    render() {
        return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null,
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(IntroComponent, { commands: this._commands })));
    }
}


/***/ }),

/***/ "./lib/components/storageProvider.js":
/*!*******************************************!*\
  !*** ./lib/components/storageProvider.js ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ StorageProvider)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/Grid/Grid */ "./node_modules/@material-ui/core/Grid/Grid.js");
/* harmony import */ var _material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/core/InputLabel/InputLabel */ "./node_modules/@material-ui/core/InputLabel/InputLabel.js");
/* harmony import */ var _material_ui_core_Select__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @material-ui/core/Select */ "./node_modules/@material-ui/core/esm/Select/Select.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @material-ui/core/FormControl */ "./node_modules/@material-ui/core/esm/FormControl/FormControl.js");
/* harmony import */ var _cspDetails__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./cspDetails */ "./lib/components/cspDetails.js");
/* harmony import */ var _viewImportList__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./viewImportList */ "./lib/components/viewImportList.js");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/Typography.js");









function StorageProvider(props) {
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
        validateCredentials();
    }, []);
    const [isValid, setIsValid] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const [provider, setProvider] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
    const listValue = [];
    var username = '';
    var bucketname = '';
    function handleChange(event) {
        setProvider(event.target.value);
    }
    ;
    const validateCredentials = async () => {
        try {
            const data = await (0,_handler__WEBPACK_IMPORTED_MODULE_1__.requestAPI)('config_api');
            if (data.isValid) {
                setIsValid(true);
                username = data.username;
                bucketname = data.bucketName;
                props.stateHandler({
                    myval: JSON.stringify(data),
                    page: 2,
                    userName: data.username,
                    bucketName: data.bucketName
                });
            }
            else {
                setIsValid(false);
            }
        }
        catch (reason) {
            console.error(`Unable to retrieve config details`);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", null,
        provider === "10" && react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: { marginBottom: "3em" } },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_2__["default"], { style: { fontSize: "0.85rem", width: "236px" }, variant: "h6", align: "left" },
                "Make sure to use IAM user credentials with programmatic access and appropriate policies.",
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement("a", { style: { color: "#106ba3" }, href: "https://docs.aws.amazon.com/IAM/latest/UserGuide/id_users_create.html#id_users_create_console", target: "_blank" }, "See Creating IAM Users (console)"),
                " for more information.")),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { style: provider === "10" && isValid ? { display: 'none' } : {} },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_3__["default"], { item: true },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_FormControl__WEBPACK_IMPORTED_MODULE_4__["default"], { variant: "filled", style: { margin: 1, minWidth: 120, width: "125%" } },
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_InputLabel_InputLabel__WEBPACK_IMPORTED_MODULE_5__["default"], { id: "test-select-label", style: { margin: "-20px", marginLeft: "14px", minWidth: 120, width: "125%" } }, "Service Provider"),
                    react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Select__WEBPACK_IMPORTED_MODULE_6__["default"], { native: true, value: provider, onChange: handleChange, labelId: "test-select-label", label: "Service Provider" },
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: "" }),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 10 }, "Amazon Web Services S3"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 20, disabled: true }, "Azure Blob Storage"),
                        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("option", { value: 30, disabled: true }, "Google Cloud Storage")))),
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_3__["default"], { item: true }, provider === "10" && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_cspDetails__WEBPACK_IMPORTED_MODULE_7__["default"], { stateHandler: props.stateHandler }))),
        provider === "10" && isValid && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_viewImportList__WEBPACK_IMPORTED_MODULE_8__["default"], { stateHandler: props.stateHandler, viewList: listValue, userName: username, bucketName: bucketname, commands: props.commands })));
}


/***/ }),

/***/ "./lib/components/viewImportList.js":
/*!******************************************!*\
  !*** ./lib/components/viewImportList.js ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ ViewImportList)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "webpack/sharing/consume/default/react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _material_ui_lab_TreeView__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @material-ui/lab/TreeView */ "./node_modules/@material-ui/lab/esm/TreeView/TreeView.js");
/* harmony import */ var _material_ui_lab_TreeItem__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @material-ui/lab/TreeItem */ "./node_modules/@material-ui/lab/esm/TreeItem/TreeItem.js");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @material-ui/core */ "webpack/sharing/consume/default/@material-ui/core/@material-ui/core");
/* harmony import */ var _material_ui_core__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _importFileData__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./importFileData */ "./lib/components/importFileData.js");
/* harmony import */ var _material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @material-ui/core/Grid/Grid */ "./node_modules/@material-ui/core/Grid/Grid.js");
/* harmony import */ var _handler__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../handler */ "./lib/handler.js");
/* harmony import */ var _material_ui_icons_Refresh__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @material-ui/icons/Refresh */ "./node_modules/@material-ui/icons/Refresh.js");
/* harmony import */ var mdbreact__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! mdbreact */ "webpack/sharing/consume/default/mdbreact/mdbreact?0ae1");
/* harmony import */ var mdbreact__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(mdbreact__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @material-ui/core/styles */ "./node_modules/@material-ui/core/esm/styles/makeStyles.js");
/* harmony import */ var _material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @material-ui/core/Button */ "./node_modules/@material-ui/core/esm/Button/Button.js");
/* harmony import */ var _material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @material-ui/core/Typography */ "./node_modules/@material-ui/core/esm/Typography/Typography.js");
/* harmony import */ var _material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @material-ui/core/CircularProgress */ "./node_modules/@material-ui/core/esm/CircularProgress/CircularProgress.js");














const useStyles = (0,_material_ui_core_styles__WEBPACK_IMPORTED_MODULE_3__["default"])((theme) => ({
    checkboxstyles: {
        "& .MuiSvgIcon-root": { fontSize: "0.7em", marginLeft: "0.25em" }
    },
    divStyles: {
        width: "80%"
    },
    parentDisable: {
        display: "none"
    },
    overlayBox: {
        position: "absolute",
        top: "30%",
        left: "40%",
        transform: "translate(-50%, -50%)",
        color: "blue",
        opacity: .8,
        zIndex: 1000
    },
    importTextStyles: {
        position: "absolute",
        top: "50%",
        left: "15%",
        fontSize: "0.8rem",
        fontWeight: "bold"
    },
    viewBtnStyles: {
        position: "absolute",
        top: "60%",
        left: "15%",
        fontSize: "0.7rem",
        fontWeight: "bold"
    },
    continueBtnStyles: {
        position: "absolute",
        top: "60%",
        left: "40%",
        fontSize: "0.7rem",
        fontWeight: "bold"
    },
    treeStyles: {
        "& .MuiTypography-body1": {
            fontSize: "0.85rem"
        },
        "& .fa-lg": {
            fontSize: "1.1em"
        }
    },
    folderTextStyles: {
        position: "absolute",
        top: "54%",
        left: "15%",
        fontSize: "0.8rem",
        fontWeight: "bold"
    }
}));
function ViewImportList(props) {
    const classes = useStyles();
    const [selected, setSelected] = react__WEBPACK_IMPORTED_MODULE_0___default().useState([]);
    const filesPath = [];
    const initialPriBtnTxt = 'IMPORT FROM S3 BUCKET';
    const [priButtonText, setPriButtonText] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(initialPriBtnTxt);
    const initialSecBtnTxt = 'EXPORT TO THIS BUCKET';
    const [secButtonText, setSecButtonText] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(initialSecBtnTxt);
    const selectionValue = 'EXPORT';
    const [selectionValueText, setSelectionValueText] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(selectionValue);
    const intialSelectedFiles = [];
    const [selectedFiles, setSelectedFiles] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(intialSelectedFiles);
    const [isLoading, setIsLoading] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const [msgTxt, setMsgTxt] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
    const [listLoading, setListLoading] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const [isImport, setIsImport] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(true);
    const intialExportedFiles = [];
    const [exportedFiles, setExportedFiles] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(intialExportedFiles);
    const [hideTreeView, setHideTreeView] = react__WEBPACK_IMPORTED_MODULE_0___default().useState(false);
    const [folderTxt, setFolderTxt] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('');
    const [folderRoot, setFolderRoot] = react__WEBPACK_IMPORTED_MODULE_0___default().useState('home');
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
        importList();
    }, []);
    function getChildById(node, id) {
        let array = [];
        function getAllChild(nodes) {
            if (nodes === null)
                return [];
            array.push(nodes.id);
            if (Array.isArray(nodes.children)) {
                nodes.children.forEach((node) => {
                    array = [...array, ...getAllChild(node)];
                    array = array.filter((v, i) => array.indexOf(v) === i);
                });
            }
            return array;
        }
        function getNodeById(nodes, id) {
            if (nodes.id === id) {
                return nodes;
            }
            else if (Array.isArray(nodes.children)) {
                let result = null;
                nodes.children.forEach((node) => {
                    if (!!getNodeById(node, id)) {
                        result = getNodeById(node, id);
                    }
                });
                return result;
            }
            return null;
        }
        return getAllChild(getNodeById(node, id));
    }
    function getOnChange(checked, nodes) {
        var filesSelected = selectedFiles;
        var exFiles = [];
        if (nodes) {
            filesPath.push(nodes);
        }
        const allNode = getChildById({
            id: "0",
            name: "Parent",
            children: (0,_importFileData__WEBPACK_IMPORTED_MODULE_4__.convertPath)(props.viewList)
        }, nodes.id);
        let array = checked
            ? [...selected, ...allNode]
            : selected.filter((value) => !allNode.includes(value));
        array = array.filter((v, i) => array.indexOf(v) === i);
        var pathList = props.viewList;
        for (var i = 0; i < filesPath.length; i++) {
            let index = 0;
            pathList.filter((element) => {
                if (element.includes(filesPath[i].name)) {
                    let existingindex = filesSelected.indexOf(index);
                    if (existingindex > -1) {
                        filesSelected = filesSelected.filter(function (item) {
                            return item !== index;
                        });
                    }
                    else {
                        var lastItem = pathList[index].split("/").pop();
                        if (lastItem != "") {
                            filesSelected.push(index);
                        }
                    }
                }
                index = index + 1;
            });
            //filesSelected.push(result);                       
        }
        setSelectedFiles([]);
        setSelectedFiles(filesSelected);
        setSelected(array);
        if (priButtonText == 'EXPORT TO S3 BUCKET') {
            filesSelected.map(function (val) {
                return exFiles.push(pathList[val]);
            });
            setExportedFiles(exFiles);
        }
    }
    const renderTree = (nodes) => (react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_lab_TreeItem__WEBPACK_IMPORTED_MODULE_5__["default"], { nodeId: nodes.id, label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.FormControlLabel, { control: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.Checkbox, { className: classes.checkboxstyles, color: "primary", checked: selected.some((item) => item === nodes.id), onChange: (event) => getOnChange(event.currentTarget.checked, nodes), onClick: (e) => e.stopPropagation() }), label: react__WEBPACK_IMPORTED_MODULE_0___default().createElement((react__WEBPACK_IMPORTED_MODULE_0___default().Fragment), null, nodes.name), key: nodes.id }) }, Array.isArray(nodes.children)
        ? nodes.children.map((node) => renderTree(node))
        : null));
    const importList = async () => {
        setFolderRoot('home');
        setListLoading(true);
        props.stateHandler({
            page: 2,
            listArray: []
        });
        try {
            const data = await (0,_handler__WEBPACK_IMPORTED_MODULE_6__.requestAPI)('list_api');
            props.stateHandler({
                page: 2,
                listArray: data
            });
        }
        catch (reason) {
            console.error(`The csp_storage server extension appears to be missing.\n${reason}`);
        }
        setListLoading(false);
    };
    const OnRefreshList = async () => {
        if (priButtonText == 'IMPORT FROM S3 BUCKET') {
            (async () => {
                await importList();
            })();
        }
        else {
            (async () => {
                await exportList();
            })();
        }
    };
    const exportList = async () => {
        setListLoading(true);
        setFolderRoot('Root');
        props.stateHandler({
            page: 2,
            listArray: []
        });
        try {
            const data = await (0,_handler__WEBPACK_IMPORTED_MODULE_6__.requestAPI)('export_list_api');
            props.stateHandler({
                page: 2,
                listArray: data
            });
            console.log("export list data ::", data);
        }
        catch (reason) {
            console.error(`The csp_storage server extension appears to be missing.\n${reason}`);
        }
        setListLoading(false);
    };
    function buttonSelected(btnName) {
        setSelected([]);
        setSelectedFiles([]);
        if (btnName == 'EXPORT') {
            (async () => {
                await exportList();
            })();
            setPriButtonText('EXPORT TO S3 BUCKET');
            setSecButtonText('IMPORT TO DEV CLOUD');
            setSelectionValueText('IMPORT');
            setIsImport(false);
        }
        else {
            (async () => {
                await importList();
            })();
            setPriButtonText('IMPORT FROM S3 BUCKET');
            setSecButtonText('EXPORT TO THIS BUCKET');
            setSelectionValueText('EXPORT');
            setIsImport(true);
        }
    }
    function priBtnSelected() {
        setIsLoading(true);
        setFolderTxt('');
        if (priButtonText == 'IMPORT FROM S3 BUCKET') {
            (async () => {
                await importData();
            })();
        }
        else {
            (async () => {
                await exportData();
            })();
        }
    }
    const importData = async () => {
        setMsgTxt('');
        //setIsLoading(true);
        setHideTreeView(true);
        console.log("files selected for import :: ", selectedFiles);
        var msg = '';
        var count = 1;
        setFolderTxt('DevCloud and are located in your ' + '/cloud-imports/s3/' + props.bucketName + ' folder');
        try {
            await Promise.all(selectedFiles.map(async (file) => {
                const dataToSend = { index: file, my_type: "download" };
                await (0,_handler__WEBPACK_IMPORTED_MODULE_6__.requestAPI)('list_api', {
                    body: JSON.stringify(dataToSend),
                    method: 'POST',
                });
                msg = count + ' files have been successfully imported to';
                setMsgTxt(msg);
                count = count + 1;
            }));
        }
        catch (reason) {
            setIsLoading(false);
            console.error(`Unable to import  file \n${reason}`);
        }
    };
    react__WEBPACK_IMPORTED_MODULE_0___default().useEffect(() => {
        let finalMsg;
        if (priButtonText == 'IMPORT FROM S3 BUCKET') {
            finalMsg = selectedFiles.length + ' files have been successfully imported to';
        }
        else {
            finalMsg = exportedFiles.length + ' files have been successfully exported to';
        }
        if (msgTxt == finalMsg) {
            setIsLoading(false);
            //setMsgTxt('');
        }
    }, [msgTxt]);
    const exportData = async () => {
        setMsgTxt('');
        //setIsLoading(true);
        setHideTreeView(true);
        setFolderTxt('S3 and are located in your /devcloud-exports folder');
        console.log("files selected for export is :: ", exportedFiles);
        var msg = '';
        var count = 1;
        try {
            await Promise.all(exportedFiles.map(async (file) => {
                var fileName = file.split("/").pop();
                const dataToSend = { UPLOAD_FILE_PATH: file, my_type: "upload", FILENAME: fileName };
                await (0,_handler__WEBPACK_IMPORTED_MODULE_6__.requestAPI)('list_api', {
                    body: JSON.stringify(dataToSend),
                    method: 'POST',
                });
                msg = count + ' files have been successfully exported to';
                setMsgTxt(msg);
                count = count + 1;
            }));
        }
        catch (reason) {
            setIsLoading(false);
            console.error(`Unable to export file \n${reason}`);
        }
    };
    const viewFunction = function () {
        if (priButtonText == 'IMPORT FROM S3 BUCKET') {
            props.commands.execute('filebrowser:go-to-path', { 'path': '/cloud-imports/s3/' + props.bucketName }).catch((reason) => {
                console.error(`An error occurred during the execution of filebrowser:go-to-path command.\n${reason}`);
            });
        }
        else {
            setHideTreeView(false);
            (async () => {
                await importList();
            })();
        }
    };
    const disconnectProvider = async () => {
        try {
            await (0,_handler__WEBPACK_IMPORTED_MODULE_6__.requestAPI)('disconnect');
            props.stateHandler({
                page: 0
            });
        }
        catch (reason) {
            console.error(`Unable to disconnect provider \n${reason}`);
        }
    };
    return (react__WEBPACK_IMPORTED_MODULE_0___default().createElement("div", { className: classes.divStyles },
        listLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_7__["default"], { className: classes.overlayBox, color: "primary" }),
        isLoading && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_CircularProgress__WEBPACK_IMPORTED_MODULE_7__["default"], { className: classes.overlayBox, color: "primary" }),
        hideTreeView && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], { className: classes.importTextStyles }, msgTxt),
        hideTreeView && msgTxt && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], { className: classes.folderTextStyles }, folderTxt),
        hideTreeView && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__["default"], { className: classes.viewBtnStyles, variant: "contained", type: "submit", color: "primary", onClick: () => viewFunction() }, "View"),
        hideTreeView && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__["default"], { className: classes.continueBtnStyles, variant: "contained", type: "submit", color: "primary", onClick: () => setHideTreeView(false) }, "Continue"),
        isImport && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], { style: { fontSize: "0.85rem", fontWeight: "bold" }, variant: "h6", align: "left" }, "Connected to: Amazon S3"),
        !isImport && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], { style: { fontSize: "0.85rem", fontWeight: "bold" }, variant: "h6", align: "left" }, "Connected to: DevCloud"),
        isImport && react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Typography__WEBPACK_IMPORTED_MODULE_8__["default"], { style: { fontSize: "0.85rem", fontWeight: "bold" }, variant: "h6", align: "left" },
            "Bucket Name : ",
            props.bucketName),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__["default"], { style: { float: "left", fontSize: "0.7rem" }, type: "submit", color: "primary", onClick: () => disconnectProvider() }, "Disconnect"),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__["default"], { style: hideTreeView ? { display: 'none' } : { float: "right", fontSize: "0.7rem" }, type: "submit", color: "primary", onClick: () => buttonSelected(selectionValueText) }, secButtonText),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement("hr", { style: { color: '#000000', backgroundColor: '#000000', height: .1, borderColor: '#000000', marginTop: '3em' } }),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Button__WEBPACK_IMPORTED_MODULE_9__["default"], { disabled: hideTreeView, style: { float: "right", marginBottom: "2em", marginTop: "0.5em", fontSize: "0.7rem", width: "184px" }, variant: "contained", type: "submit", color: "primary", onClick: () => priBtnSelected() }, priButtonText),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core_Grid_Grid__WEBPACK_IMPORTED_MODULE_10__["default"], { item: true },
            react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_core__WEBPACK_IMPORTED_MODULE_1__.IconButton, { style: { fontSize: "2rem" }, name: "refreshList", onClick: () => OnRefreshList() },
                react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_icons_Refresh__WEBPACK_IMPORTED_MODULE_11__["default"], { color: "primary" }))),
        react__WEBPACK_IMPORTED_MODULE_0___default().createElement(_material_ui_lab_TreeView__WEBPACK_IMPORTED_MODULE_12__["default"], { className: classes.treeStyles, style: hideTreeView ? { display: 'none' } : {}, defaultCollapseIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__.MDBIcon, { far: true, icon: "folder-open", size: "lg" }), defaultExpanded: ["0", "3", "4"], defaultExpandIcon: react__WEBPACK_IMPORTED_MODULE_0___default().createElement(mdbreact__WEBPACK_IMPORTED_MODULE_2__.MDBIcon, { icon: "folder", size: "lg" }) }, renderTree({
            id: "0",
            name: folderRoot,
            children: (0,_importFileData__WEBPACK_IMPORTED_MODULE_4__.convertPath)(props.viewList)
        }))));
}


/***/ }),

/***/ "./lib/handler.js":
/*!************************!*\
  !*** ./lib/handler.js ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "requestAPI": () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/coreutils */ "webpack/sharing/consume/default/@jupyterlab/coreutils");
/* harmony import */ var _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__);


/**
 * Call the API extension
 *
 * @param endPoint API REST end point for the extension
 * @param init Initial values for the request
 * @returns The response body interpreted as JSON
 */
async function requestAPI(endPoint = '', init = {}) {
    // Make request to Jupyter API
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeSettings();
    const requestUrl = _jupyterlab_coreutils__WEBPACK_IMPORTED_MODULE_0__.URLExt.join(settings.baseUrl, 'csp-storage', // API Namespace
    endPoint);
    let response;
    try {
        response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.makeRequest(requestUrl, init, settings);
    }
    catch (error) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.NetworkError(error);
    }
    let data = await response.text();
    if (data.length > 0) {
        try {
            data = JSON.parse(data);
        }
        catch (error) {
            console.log('Not a JSON response body.', response);
        }
    }
    if (!response.ok) {
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_1__.ServerConnection.ResponseError(response, data.message || data);
    }
    return data;
}


/***/ }),

/***/ "./lib/index.js":
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/application */ "webpack/sharing/consume/default/@jupyterlab/application");
/* harmony import */ var _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _components_intro__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./components/intro */ "./lib/components/intro.js");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/filebrowser */ "webpack/sharing/consume/default/@jupyterlab/filebrowser");
/* harmony import */ var _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__);



/**
 * Initialization data for the csp-storage extension.
 */
const plugin = {
    id: 'csp-storage:plugin',
    autoStart: true,
    requires: [
        _jupyterlab_application__WEBPACK_IMPORTED_MODULE_0__.ILayoutRestorer,
        _jupyterlab_filebrowser__WEBPACK_IMPORTED_MODULE_1__.IFileBrowserFactory
    ],
    activate: async (app, restorer) => {
        console.log('JupyterLab extension csp-storage is activated!');
        const introWidget = new _components_intro__WEBPACK_IMPORTED_MODULE_2__.IntroWidget(app.commands);
        introWidget.title.iconClass = 'test1-icon';
        introWidget.title.caption = 'Cloud Storage Connector';
        introWidget.id = 'intro-page-view';
        restorer.add(introWidget, 'intropage');
        app.shell.add(introWidget, 'left', { rank: 1000 });
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ })

}]);
//# sourceMappingURL=lib_index_js.89a554ce41761fb0569e.js.map